nome = string(input("insira o nome: "))
sobrenome =string(input("insira sobrenome: "))

nomecompleto = string(nome ' ' sobrenome)


print(f'o nome digitado é  {nomecompleto}')