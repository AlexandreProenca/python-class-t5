lado1 =int(input("insira o valor da lado 1: "))
lado2 =int(input("insira o valor da lado 2: "))
lado3 =int(input("insira o valor da lado 3: "))
lado4 =int(input("insira o valor da lado 4: "))
media = float((lado1+lado2+lado3+lado4)/4)


print(f'a area do quadrado é  {media}')