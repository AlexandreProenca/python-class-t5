numero =int(input("escreva um numero: "))

print(f'o numero digitado foi  {numero}')