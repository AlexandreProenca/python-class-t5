lado1 =int(input("insira o valor da lado 1: "))
lado2 =int(input("insira o valor da lado 2: "))


print(f'a area do quadrado é  {lado1*lado2}')